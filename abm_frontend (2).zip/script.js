
document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;

    if (user === "Burak06" && pass === "010101") {
        window.location.href = "/chat.html";
    } else {
        document.getElementById("message").innerText = "Hatalı kullanıcı adı veya şifre!";
    }
});
