
document.getElementById("login-form").addEventListener("submit", function (e) {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if ((username === "Burak06" && password === "010101") || 
        (username === "Melis06" && password === "000000")) {
        document.getElementById("login-message").textContent = "Giriş başarılı!";
        window.location.href = "chat.html";
    } else {
        document.getElementById("login-message").textContent = "Hatalı giriş!";
    }
});
